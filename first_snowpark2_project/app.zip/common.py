def print_hello(name: str):
    return f"Hello {name}!"
